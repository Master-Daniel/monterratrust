<footer class="footer-section">
    <div class="footer-section__bottom">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <p>{{date('Y')}} © <a href="{{ route('home') }}">{{__(gs('site_name'))}}</a>. @lang('All Right Reserved')</p>
                </div>
            </div>
        </div>
    </div>
</footer>